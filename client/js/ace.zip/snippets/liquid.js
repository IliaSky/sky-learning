ace.define("ace/snippets/liquid",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "liquid";

});
                (function() {
                    ace.require(["ace/snippets/liquid"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            